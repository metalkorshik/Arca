---
name: Feature request / предложить новую функциональность
about: Suggest an idea or function for this project / предложить новую идею или функциональность
title: ''
labels: ''
assignees: ''

---

**Description / Описание**
A clear and concise description of your suggestion.
Детальное описание вашего предложения.
